//jshint esversion:6

const express = require("express");
const bodyParser = require("body-parser");
const ejs = require("ejs");
const mongoose = require('mongoose');

const homeStartingContent = "This is a daily journal Website which shows our daily posts for our day to day studies and it is a personal Webiste The daily log is when you journal about your day-to-day: what you did, what you ate, who you saw and spoke with. Whatever you want. It’s a working way to log your life. The best part about this journaling habit is that you literally have a hand-written record of what you’ve done on any given day… And believe me when I tell you that it comes in handy."
const aboutContent = "This is Project develop by Third year student from IT department With Roll NO:017 Name: Rushikesh Kadam, Roll No:13 Name:Prasad Bhosale, Roll No:46 Name:Sakshi Kulkarni ";
const contactContent = "Rushikesh Kadam: 9850150552, Prasad Bhosale: 8530649158, Sakshi Kulkarni: 9637316600";

const app = express();

app.set('view engine', 'ejs');

app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static("public"));

mongoose.connect("mongodb://localhost:27017/blogDB", {useNewUrlParser: true});

const postSchema = {
  title: String,
  content: String
};

const Post = mongoose.model("Post", postSchema);

app.get("/", function(req, res){

  Post.find({}, function(err, posts){
    res.render("home", {
      startingContent: homeStartingContent,
      posts: posts
      });
  });
});

app.get("/compose", function(req, res){
  res.render("compose");
});

app.post("/compose", function(req, res){
  const post = new Post({
    title: req.body.postTitle,
    content: req.body.postBody
  });


  post.save(function(err){
    if (!err){
        res.redirect("/");
    }
  });
});

app.get("/posts/:postId", function(req, res){

const requestedPostId = req.params.postId;

  Post.findOne({_id: requestedPostId}, function(err, post){
    res.render("post", {
      title: post.title,
      content: post.content
    });
  });

});

app.get("/about", function(req, res){
  res.render("about", {aboutContent: aboutContent});
});

app.get("/contact", function(req, res){
  res.render("contact", {contactContent: contactContent});
});

// app.get("/compose", function(req,res){
//   res.render("compose", {composeCompose: composeCompose});
// });


app.listen(3000, function() {
  console.log("Server started on port 3000");
});
